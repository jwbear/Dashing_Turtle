import sys, os
import re
import platform
import subprocess
import sys
import pandas as pd
import numpy as np


# # Open the file in read mode
# with open('/Users/timshel/structure_landscapes/DashML/Parse/ecoli_paper copy.txt', 'r') as file:
#     # Read each line in the file
#     ecoli = [0] * 364
#     seen = []
#     for i, line in enumerate(file):
#         if re.search('#', line):
#             continue
#         l = re.split('\\s', line.strip())
#         if len(l) < 3:
#             continue
#         pos = int(l[0]) - 1
#         close = int(l[2]) - 1
#         #print(pos,close)
#         if close == -1:
#             ecoli[pos] = '.'
#         elif close not in seen:
#                 ecoli[pos] = '('
#                 seen.append(close)
#         elif close in seen:
#             ecoli[close] = ')'
#
# print(*ecoli, sep='')


# #update structure to psuedoknot free
# s = "hc16_ligase"
# psuedo = "(((((((([[.....))))))))...................((((((((.((((((((((.(((........(((.((((((((..((((..((....))..))))..(((]]...)))....)))....).)))))))....[[[[[.....[[[[[[[...(((((..(((((((((....)))))))))).)))).......[[.[[[[[[....))).))))))))))...))))))))..((((((((....))))))))..................]]]]]].]]..(((((((.((.......)))))))))..]]]]].]].]]]]]."
#
# for i, n in enumerate(psuedo):
#  if re.search("\(|\)|\.", n):
#      a = 'Y'
#  else:
#      #print(n)
#      a = "P"
#  query = 'UPDATE Structure SET Structure.accessible="{0}" WHERE position={1} AND contig="{2}";'.format(a, i, s)
#  print(query)


#update structure base pairs to psuedoknot free
s = "HCV"
psuedo = "...................................((((.((((.....(((((..(((.((...((((((.......))))))....)).)))..).))))))))))))......(((((((((((.(((((((((((((((((..((((((....))))))((((((((((..(((.((((..............))))).))....)))))))))).(((....))))))).)))))))))((((..(((((......))))).))))....))))[))((((..].))))((.[[[[[[.))))))))))).]]]]]]((.(((((.......)))))..))...................................."
#p2 = re.sub("\{|\}|\[|\]", ".", psuedo)
#print(p2)

for i, n in enumerate(psuedo):
 if re.search("\(|\)", n):
     a = 'B'
 else:
     #print(n)
     a = "S"
 query = 'UPDATE `Structure` SET `Structure`.base_type="{0}" WHERE `position`={1} AND contig="{2}";'.format(a, i, s)
 print(query)
